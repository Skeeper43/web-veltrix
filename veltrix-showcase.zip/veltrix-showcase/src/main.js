import './style.css';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const loader = $('#loader');
const loadBar = $('#load-bar');
const loadPercent = $('#load-percent');

let progress = 0;
const loaderTimer = window.setInterval(() => {
  progress = Math.min(100, progress + Math.ceil(Math.random() * 17));
  loadBar.style.width = `${progress}%`;
  loadPercent.textContent = `${String(progress).padStart(2, '0')}%`;
  if (progress >= 100) {
    window.clearInterval(loaderTimer);
    window.setTimeout(() => {
      loader.classList.add('loader-done');
      document.body.classList.add('is-ready');
      window.setTimeout(() => loader.remove(), 900);
    }, 180);
  }
}, 75);

$('#year').textContent = new Date().getFullYear();

const menuToggle = $('#menu-toggle');
const nav = $('#nav');

function closeMenu() {
  menuToggle.classList.remove('active');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Open navigation');
  nav.classList.remove('nav-open');
  document.body.classList.remove('menu-open');
}

menuToggle.addEventListener('click', () => {
  const open = !nav.classList.contains('nav-open');
  nav.classList.toggle('nav-open', open);
  menuToggle.classList.toggle('active', open);
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  document.body.classList.toggle('menu-open', open);
});

$$('#nav a').forEach(link => link.addEventListener('click', closeMenu));
window.addEventListener('resize', () => {
  if (window.innerWidth > 800) closeMenu();
});

const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

$$('.reveal').forEach(el => revealObserver.observe(el));

const cursorGlow = $('#cursor-glow');
const finePointer = window.matchMedia('(pointer: fine)').matches;
if (finePointer) {
  window.addEventListener('pointermove', event => {
    cursorGlow.style.left = `${event.clientX}px`;
    cursorGlow.style.top = `${event.clientY}px`;
    cursorGlow.classList.add('glow-visible');
  }, { passive: true });
  document.addEventListener('pointerleave', () => cursorGlow.classList.remove('glow-visible'));
} else {
  cursorGlow.remove();
}

const projects = [
  {
    category: 'PROJECT / 001 — IDENTITY',
    title: 'NØVA',
    description: 'A conceptual visual identity for a next-generation creative label. Sharp geometry, electric contrast, and a system designed to feel in motion.',
    type: 'BRAND STRATEGY · VISUAL IDENTITY'
  },
  {
    category: 'PROJECT / 002 — CAMPAIGN',
    title: 'AFTER DARK',
    description: 'A cinematic campaign concept built around atmosphere, contrast, and the energy of a city after hours.',
    type: 'ART DIRECTION · CAMPAIGN'
  },
  {
    category: 'PROJECT / 003 — DIGITAL',
    title: 'SYSTEM',
    description: 'An experimental digital world exploring signal, disruption, and the beauty of things that refuse to behave.',
    type: 'DIGITAL EXPERIENCE · MOTION'
  }
];

const modal = $('#project-modal');
const modalTitle = $('#modal-title');
const modalCategory = $('#modal-category');
const modalDescription = $('#modal-description');
const modalType = $('#modal-type');
let previousFocus = null;

function openModal(index) {
  const project = projects[index];
  if (!project) return;
  previousFocus = document.activeElement;
  modalCategory.textContent = project.category;
  modalTitle.textContent = project.title;
  modalDescription.textContent = project.description;
  modalType.textContent = project.type;
  modal.classList.add('modal-open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-active');
  $('.modal-close').focus();
}

function closeModal() {
  modal.classList.remove('modal-open');
  modal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-active');
  if (previousFocus) previousFocus.focus();
}

$$('[data-project]').forEach(button => {
  button.addEventListener('click', () => openModal(Number(button.dataset.project)));
});
$$('[data-close-modal]').forEach(button => button.addEventListener('click', closeModal));

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    closeModal();
    closeMenu();
  }
});

$$('a[href^="#"]').forEach(link => {
  link.addEventListener('click', event => {
    const target = $(link.getAttribute('href'));
    if (!target) return;
    event.preventDefault();
    target.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    history.replaceState(null, '', link.getAttribute('href'));
  });
});
